<?php

class Drive extends fActiveRecord
{
    protected function configure()
    {
    }
}