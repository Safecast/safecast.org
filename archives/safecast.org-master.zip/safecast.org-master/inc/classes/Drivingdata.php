<?php

class Drivingdata extends fActiveRecord
{
    protected function configure()
    {
    }
}