<?php

class Fleepdata extends fActiveRecord
{
    protected function configure()
    {
    }
}