<?php

class Fukushimadata extends fActiveRecord
{
    protected function configure()
    {
    }
}