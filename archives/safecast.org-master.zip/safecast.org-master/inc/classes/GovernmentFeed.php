<?php

class GovernmentFeed extends fActiveRecord
{
    protected function configure()
    {
    }
}