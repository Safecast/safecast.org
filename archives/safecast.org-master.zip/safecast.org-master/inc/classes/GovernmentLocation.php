<?php

class GovernmentLocation extends fActiveRecord
{
    protected function configure()
    {
    }
}