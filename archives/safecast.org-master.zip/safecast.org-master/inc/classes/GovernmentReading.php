<?php

class GovernmentReading extends fActiveRecord
{
    protected function configure()
    {
    }
}