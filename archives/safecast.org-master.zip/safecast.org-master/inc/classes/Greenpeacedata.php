<?php

class Greenpeacedata extends fActiveRecord
{
    protected function configure()
    {
    }
}