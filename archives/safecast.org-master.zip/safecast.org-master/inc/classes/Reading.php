<?php

class Reading extends fActiveRecord
{
    protected function configure()
    {
    }
}