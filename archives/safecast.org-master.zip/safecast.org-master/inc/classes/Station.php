<?php

class Station extends fActiveRecord
{
    protected function configure()
    {
    }
}