<?php

class Stationdata extends fActiveRecord
{
    protected function configure()
    {
    }
}