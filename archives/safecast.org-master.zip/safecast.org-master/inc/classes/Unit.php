<?php

class Unit extends fActiveRecord
{
    protected function configure()
    {
    }
}