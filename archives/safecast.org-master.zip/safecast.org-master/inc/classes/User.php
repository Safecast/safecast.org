<?php

class User extends fActiveRecord
{
    protected function configure()
    {
    }
}