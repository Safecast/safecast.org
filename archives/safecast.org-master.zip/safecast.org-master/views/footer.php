
			
	</div>
	</div>	
	<div class="rowSpacer50"> </div> 
	<div id="footer"> 
		<div class="footerInside">
			<div class="footerColumnLeft"> 
				<div class="footerHeader footerHeaderText"><?php echo $this->get('contact'); ?></div> 
				<div class="footerText">
				    				<div class="footerTextLinks">
    					<span class="bold_caps">GENERAL 全般:</span> <a href="mailto:info@safecast.org">info@safecast.org</a><br/>
    					<span class="bold_caps">JAPAN 日本:</span> <a href="mailto:japan@safecast.org">japan@safecast.org</a><br/>
    					<span class="bold_caps">PRESS プレス:</span> <a href="mailto:sean@safecast.org">press@safecast.org</a><br/>
    					<span class="bold_caps">VOLUNTEER:</span> <a href="https://spreadsheets.google.com/spreadsheet/viewform?formkey=dGNfLUFXdi1lejF1TzU4NHdhZnRGWkE6MQ">Interested in helping?</a><br/>
    					<span class="bold_caps">ボランティア:</span> <a href="http://safecast.org/ja/2011/06/interested-in-helping/">ボランティアに興味をお持ちですか？</a><br/>
    				</div>
					<br/>					<br/>
					<div class="terms"><a href="http://blog.safecast.org/terms-conditions">Terms and Conditions</a></div>
				</div> 
			</div> 
			<div class="footerColumnRight"> 
				<div class="footerHeader footerHeaderText"><?php echo $this->get('follow'); ?></div> 
				<div class="footerText"> 
    				<div class="footerTextLinks">
        				<a href="http://www.twitter.com/safecastdotorg"><img class="twitter" src="/images/twitter_icon.png" alt="Twitter" /> @safecastdotorg</a><br />
        				<a href="http://www.twitter.com/safecastjapan"><img class="twitter" src="/images/twitter_icon.png" alt="Twitter" /> @safecastjapan</a><br />
        				<a href="http://www.flickr.com/groups/safecast"><img class="twitter" src="/images/flickr.png" alt="Flickr" />Safecast on Flickr</a><br /> 
        				<a href="http://groups.google.com/group/safecast-japan">Discussion mailing list</a>
                    </div>
			</div>	
		</div>	
	</div>
	
		<script type="text/javascript">
		
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-21121279-2']);
		_gaq.push(['_trackPageview']);
		
		(function() {
		  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		  ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		 })();
		
		</script>
	</body>
</html>
